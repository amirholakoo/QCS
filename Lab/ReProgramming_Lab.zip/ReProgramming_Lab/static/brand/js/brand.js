function AddBrandsSuggestion(data) {
    const brand_suggestion_element = document.getElementById("brand_suggestion");
    data.result.forEach(brand => {brand_suggestion_element.insertAdjacentHTML("beforeend",`
        ${'<option value="'+brand.Name+'">'}`
    )})
}