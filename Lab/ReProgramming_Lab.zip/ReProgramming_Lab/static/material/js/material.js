function DisplayMaterial(data) {
    let location = document.querySelector("#paper_section_8 .form_body");
    if (data) {
        for (const x of data.result) {
            if (!document.getElementById(`Material_Form_Object_${x.id}`)) {
                location.insertAdjacentHTML("beforeend",`
                    <div class="form_multi_group">
                        <div class="header">
                            <div class="form_group check-box">
                                <input id="Material_Form_Object_${x.id}" name="Material_Form_Object_${x.id}" type="checkbox">
                                <label for="Material_Form_Object_${x.id}" style="font-size: var(--lg-font);">${x.Name}</label>
                            </div>
                        </div>
                        <div class="body">
                            <div class="form_group">
                                <input id="Material_Form_Value_${x.id}" name="Material_Form_Value_${x.id}" type="number" step="0.01" placeholder="مثال: 8">
                                <label for="Material_Form_Value_${x.id}">مقدار</label>
                            </div>
                            <div class="form_group">
                                <input id="Material_Form_Dissolved_Amount_${x.id}" name="Material_Form_Dissolved_Amount_${x.id}" type="number" max="4000"
                                        oninput="if(this.value > 4000) {
                                            this.value = 4000;
                                            AM_alert({status : 'error', text:'مقدار باید بین 1 تا 4000 باشد',btns:false,obj:false});
                                        }
                                        "
                                        placeholder="1 تا 4000">
                                <label for="Material_Form_Dissolved_Amount_${x.id}">محلول در آب</label>
                            </div>
                            <div class="form_group">
                                <input id="Material_Form_Brand_${x.id}" name="Material_Form_Brand_${x.id}" type="text" step="0.01" placeholder="مثال: RUSTIN SHIMI" list="brand_suggestion">
                                <label for="Material_Form_Brand_${x.id}">برند</label>
                            </div>
                            <div class="form_group">
                                <input id="Material_Form_Desc_${x.id}" name="Material_Form_Desc_${x.id}" type="text" step="0.01" placeholder="">
                                <label for="Material_Form_Desc_${x.id}">توضیحات</label>
                            </div>
                        </div>
                    </div>
                `)
            }
        }
    }
}