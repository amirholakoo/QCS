const PAGE_DATA = {};
let currentPage = null;

const PAGE_API = {

    paper_create_form: [

        {
            url: "/paper/paper_type/all/",
            state: null, //"dashboard.rolls",
            callback: DisplayPaperType
        },
        {
            url: "/material/all/",
            state: null, //"dashboard.rolls",
            callback: DisplayMaterial
        },
        {
            url: "/brand/all/",
            state: "brand.all",
            callback: AddBrandsSuggestion,
        }

    ],

};

const GLOBAL_API = [

    {
        url: "base/current_date/",
        state: "global.current_date",
        callback: DisplayFormsDate,
    }

];

function SetPageData(path, value) {
    const keys = path.split(".");
    let target = PAGE_DATA;
    for (let i = 0; i < keys.length - 1; i++) {

        if (
            !target[keys[i]] || typeof target[keys[i]] !== "object") {
            target[keys[i]] = {};
        }
        target = target[keys[i]];
    }
    target[keys[keys.length - 1]] = value;
}

async function APIRequest({
    url,
    method = "GET",
    data = null,
    state = null,
    callback = null,
    onError = null
}) {

    try {
        const options = {
            method: method,
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        };
        /*
         * اگر data داشتیم
         */
        if (data) {
            if (data instanceof FormData) {
                options.body = data;
            } else {
                options.headers["Content-Type"] = "application/json";
                options.body = JSON.stringify(data);
            }
        }

        /*
         * Request
         */
        const response = await fetch(url, options);

        /*
         * HTTP Error
         */
        if (!response.ok) {
            throw new Error(
                `HTTP ${response.status}: ${response.statusText}`
            );
        }

        /*
         * JSON
         */
        const result = await response.json();

        /*
         * Save Data
         */
        if (state) {
            SetPageData(state, result);
        }

        /*
         * Callback
         */
        if (callback) {
            await callback(result);
        }

        return result;

    } catch (error) {

        console.error(
            "APIRequest Error:",
            url,
            error
        );
        /*
         * Custom Error Handler
         */
        if (onError) {
            await onError(error);
        } else {

            /*
             * Default Error
             */
            AM_alert({
                display: true,
                status: "danger",
                text: "خطا در دریافت اطلاعات"
            });
        }
        return null;
    }
}

async function LoadPageData(page) {

    const requests = PAGE_API[page];

    if (!requests || !requests.length) {
        return;
    }

    await Promise.all(
        requests.map(config =>
            APIRequest(config)
        )
    );
}

async function LoadGlobalData() {

    if (!GLOBAL_API || !GLOBAL_API.length) {
        return;
    }

    await Promise.all(
        GLOBAL_API.map(config =>
            APIRequest(config)
        )
    );
}

// ============ FORM API FETCH START =============
async function submitForm(form) {

    const data = {};

    for (const field of form.elements) {

        if (!field.name || field.disabled) continue;

        if (field.type === "checkbox") {
            data[field.name] = field.checked;
        }

        else if (field.type === "radio") {
            if (field.checked) {
                data[field.name] = field.value;
            }
        }

        else {
            data[field.name] = field.value;
        }
    }
    const response = await fetch(form.action, {
        method: "POST",

        headers: {
            "Content-Type": "application/json",
            // "X-CSRFToken": getCookie("csrftoken")
        },

        body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
        AM_alert({status : 'error', text:`خطای ${response.status};`,btns:false,obj:false});
    } else {
        AM_alert({status : result.status, text:`${result.alert}`,btns:false,obj:false});
    }

    return result;
}


document.querySelectorAll("form").forEach(form => {

    form.addEventListener("submit", async function (event) {

        event.preventDefault();

        try {

            const result = await submitForm(this);
            if(result.status == "success") {
                window.location = this.getAttribute("next");
            }

        } catch (error) {
            console.error(error);
            AM_alert({status : 'error', text:`خطای ${error};`,btns:false,obj:false});
        }

    });

});
// ============ FORM API FETCH END =============