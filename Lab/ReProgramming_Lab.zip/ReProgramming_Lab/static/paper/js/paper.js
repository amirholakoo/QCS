function DisplayPaperType(data) {
    
}