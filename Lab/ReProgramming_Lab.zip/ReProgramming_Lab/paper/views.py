from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from .models import *
@csrf_exempt
def AddNewPaperType(request):
    if request.method == "POST":
        data = json.loads(request.body)
        name = data.get("PaperType_Form_Name")
        desc = data.get("PaperType_Form_Desc")
        active = data.get("PaperType_Form_Active")
        print(name,desc,active)
        if not PaperType.objects.filter(Name__iexact=name).exists():
            new_PaperType = PaperType(Name=name,
                                      Desc=desc,
                                      Active=active)
            new_PaperType.save()
            return JsonResponse({"status": "success","alert":f"{new_PaperType.Name} با موفقیت ثبت و اضافه شد."})
        else:
            return JsonResponse({"status": "error","alert":f"{name} از قبل وجود دارد"})
    else: return JsonResponse(
        {
            "status": "error",
            "alert": "دسترسی غیرمجاز است."
        },
        status=403
    )


def GetAllPaperType(request):
    target = list(PaperType.objects.values())
    return JsonResponse(
        {"status": "success","result":target}
    )