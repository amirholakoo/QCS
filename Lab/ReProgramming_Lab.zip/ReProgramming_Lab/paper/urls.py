from django.urls import path,include
from .views import *
urlpatterns = [
    path('add_new_paper_type/', AddNewPaperType, name="add_new_paper_type"),
    path('paper_type/all/', GetAllPaperType)
]